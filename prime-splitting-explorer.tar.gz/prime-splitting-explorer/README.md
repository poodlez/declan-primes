# Prime Splitting Explorer

Interactive exploration of how prime numbers split in Gaussian and Eisenstein integer rings, and their speculative quantum correspondence on the Bloch sphere.

Based on ideas from [Declan Dunleavy's "Secret Life of Primes"](https://medium.com/@declandunleavy/the-secret-life-of-primes-how-numbers-split-in-complex-worlds-06f5846107f9) series.

## What it does

**Layer 1 — Factorization Geometry:** Pick any prime and watch it split (or not) in the Gaussian integers Z[i] (square lattice) and Eisenstein integers Z[ω] (hexagonal lattice). All factor points land on a circle of radius √p.

**Layer 2 — Norm Interference:** Compare the Gaussian norm (a² + b², circular contours) with the Eisenstein norm (a² − ab + b², hexagonal contours from the −ab interference term). Bright cells mark prime norms.

**Layer 3 — Bloch Sphere Encoding:** For primes that split in both rings (p ≡ 1 mod 12), the Gaussian factorization encodes amplitude (θ) and the Eisenstein factorization encodes phase (φ), together defining a unique qubit state on the Bloch sphere. This layer is experimental/speculative.

## Deploy on Render (free)

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → New → Static Site
3. Connect your GitHub repo
4. Set **Publish Directory** to `public`
5. Deploy

No build step needed. It's a single HTML file with inline JS and Three.js loaded from CDN.

## Local dev

Just open `public/index.html` in a browser. No build tools required.

## License

MIT
